package FinalProject;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.out.println("Please input the test file path and the output file path.");
            return;
        }

        String file = args[0];
        String output = args[1];
        // String file = "/Users/cinyee/IdeaProjects/AdvancedDatabaseSystems/src/FinalProject/tests/testcase1.txt";

        Site sites = new Site(10, 20);
        TransactionManager tm = new TransactionManager(sites);

        FileInputStream fstream = new FileInputStream(file);
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String strLine;

        PrintStream fileOut = new PrintStream(output);
        System.setOut(fileOut);

        while ((strLine = br.readLine()) != null) {
            if (strLine.length() < 1 || strLine.startsWith("//") || strLine.startsWith("[a-zA-Z0-9]+")) continue;
            if (strLine.startsWith("===")) break;
            //System.out.println(strLine);
            Operation operation = new Operation(strLine);
            tm.currentTick++;
            tm.checkOperationList();
            tm.operate(operation);
        }
        in.close();
    }
}

class TransactionManager {
    int currentTick;
    Site sites;
    List<Operation> operationList;
    Map<String, Transaction> transactions; // <key:transName, val:transaction>
    Map<String, List<String>> holdLockTrans; // <key:varName, val:[transName]>
    Map<String, List<String>> waitForTrans; // <key:varName, val:[transName]>
    Map<Integer, List<Integer>> siteToFailTime; // <key:siteID, val:[failedTimestamp]>
    Map<Integer, List<Integer>> siteToRecoverTime; // <key:siteID, val:[recoveryTimestamp]>

    public TransactionManager(Site sites) {
        currentTick = 0;
        this.sites = sites;
        operationList = new ArrayList<>();

        transactions = new HashMap<>();
        holdLockTrans = new HashMap<>();
        waitForTrans = new HashMap<>();
        siteToFailTime = new HashMap<>();
        siteToRecoverTime = new HashMap<>();
    }

    public void checkOperationList() {
        List<Operation> tmp = new ArrayList<>(operationList);
        for (Operation operation : operationList) {
            if (operate(operation)) {
                tmp.remove(operation);
                deleteWaitFor(operation.transName);
            }
        }
        operationList = tmp;
    }

    public boolean operate(Operation operation) {
        boolean res = true;
        switch (operation.operation) {
            case "begin": {
                Transaction transaction = new Transaction(currentTick, false);
                transactions.put(operation.transName, transaction);
                break;
            }
            case "beginro": {
                Transaction transaction = new Transaction(currentTick, true);
                transactions.put(operation.transName, transaction);
                beginro(transaction);
                break;
            }
            case "end": {
                String transName = operation.transName;
                end(transName);
                break;
            }
            case "dump": {
                for (int i = 1; i < sites.dm.size(); ++i) {
                    System.out.print("Site" + i + ":");
                    sites.dm.get(i).dump();
                    System.out.println();
                }
                break;
            }
            case "r": {
                res = read(operation);
                break;
            }
            case "w": {
                res = write(operation);
                break;
            }
            case "fail": {
                int siteID = operation.siteID;
                fail(siteID);
                break;
            }
            case "recover": {
                int siteID = operation.siteID;
                recover(siteID);
                break;
            }
            default: {
                System.out.println("Invalid operation!");
                return false;
            }
        }

        return res;
    }

    private boolean write(Operation operation) {
        //System.out.println(operation.operateStr);
        boolean res = true;
        List<Integer> availSites = getAvailableSites(operation.varName);
        //System.out.println(availSites);
        if (availSites.isEmpty()) {
            System.out.println(operation.operateStr + ": no available sites found.");
            addOperation(operation);
        }

        boolean allLocks = true, hasWaitingCandidate = false;
        if (waitForTrans.containsKey(operation.varName) && !waitForTrans.get(operation.varName).isEmpty()
                && !waitForTrans.get(operation.varName).get(0).equals(operation.transName)) {
            hasWaitingCandidate = true;
        }
        //System.out.println(hasWaitingCandidate);
        for (int siteID : availSites) {
            if (!sites.dm.get(siteID).getWriteLock(operation, hasWaitingCandidate)) {
                //System.out.println("line 152");
                allLocks = false;
                System.out.format("Request lock FAIL: %s Write %s site%d.\n", operation.transName, operation.varName, siteID);
                break;
            }
        }

        //System.out.println("line 148");
        if (allLocks) {
            System.out.format("Request lock SUCCESS: %s Write %s.\n", operation.transName, operation.varName);
            putHoldLock(operation.varName, operation.transName);
            for (int siteID : availSites) {
                sites.dm.get(siteID).write(operation.varName, operation.value);
                transactions.get(operation.transName).accessedSites.add(siteID);
            }
        } else {
            //System.out.format("Request lock fail for write: %s %s.\n", operation.transName, operation.varName);
            for (int siteID : availSites) {
                sites.dm.get(siteID).releaseWriteLock(operation.transName, operation.varName);
            }
            addOperation(operation);
            //System.out.println("line 162");
            putWaitFor(operation.varName, operation.transName);
            //System.out.println("line 164");
            abortDeadlock(operation.transName);
            res = false;
        }

        //System.out.println("line 166");
        return res;
    }

    private boolean read(Operation operation) {
        boolean res = true;
        Transaction transaction = transactions.get(operation.transName);
        if (transaction.readOnly) {
            if (operation.readOnlySites.isEmpty() && operation.readOnlySiteRecovery.isEmpty()) {
                Set<Integer> set = new HashSet<>();
                for (int i = 1; i < sites.dm.size(); ++i) {
                    for (String varName : sites.dm.get(i).variables.keySet()) {
                        if (varName.equals(operation.varName)) set.add(i);
                    }
                }
                if (set.size() == 1) {
                    operation.readUniqueVar = true;
                    operation.readOnlySites = set;
                } else {
                    for (int[] arr : transaction.readOnlyList) {
                        for (String varName : sites.dm.get(arr[0]).variables.keySet()) {
                            if (varName.equals(operation.varName)) operation.readOnlySiteRecovery.add(arr);
                        }
                    }
                }

            }
            if (operation.readUniqueVar) {
                int siteID = operation.readOnlySites.iterator().next();
                if (sites.dm.get(siteID).isUp) {
                    Integer readVal = sites.dm.get(siteID).readOnlyUnique(operation.varName, transaction.timestamp);
                    if (readVal != null) {
                        System.out.format("%s Read %s: %d.\n", operation.transName, operation.varName, readVal);
                    }
                } else {
                    System.out.format(operation.operateStr + ": site%d is down.\n", siteID);
                    addOperation(operation);
                    res = false;
                }
            } else {
                res = false;
                for (int[] arr : operation.readOnlySiteRecovery) {
                    if (sites.dm.get(arr[0]).isUp) {
                        Integer readVal = sites.dm.get(arr[0]).readOnly(operation.varName, arr[1], transaction.timestamp);
                        if (readVal != null) {
                            System.out.format("%s Read Only %s: %d.\n", operation.transName, operation.varName, readVal);
                            res = true;
                            break;
                        } else {
                            operation.readOnlySiteRecovery.remove(arr);
                        }
                    }
                }
                //System.out.println("220: " + operation.readOnlySiteRecovery);
                if (operation.readOnlySiteRecovery.isEmpty()) {
                    System.out.format("RO Abort: %s.\n", operation.transName);
                    abort(operation.transName);
                    res = true;
                }
                if (!res) addOperation(operation);
            }
        } else {
            boolean canRead = false;
            List<Integer> availSites = getAvailableSites(operation.varName);
            if (availSites.isEmpty()) {
                System.out.println(operation.operateStr + ": no available sites found.");
                addOperation(operation);
            }
            for (int siteID : availSites) {
                if (sites.dm.get(siteID).getReadLock(operation)) {
                    int readVal = sites.dm.get(siteID).read(operation.varName);
                    System.out.format("%s Read %s: %d.\n", operation.transName, operation.varName, readVal);
                    transactions.get(operation.transName).accessedSites.add(siteID);
                    putHoldLock(operation.varName, operation.transName);
                    canRead = true;
                    break;
                }
            }
            if (!canRead) {
                System.out.format("Request lock FAIL: %s Read %s; add to wait queue.\n", operation.transName, operation.varName);
                addOperation(operation);
                putWaitFor(operation.varName, operation.transName);
                abortDeadlock(operation.transName);
                res = false;
            }
        }

        return res;
    }

    private void recover(int siteID) {
        sites.dm.get(siteID).recover();
        siteToRecoverTime.putIfAbsent(siteID, new ArrayList<>());
        siteToRecoverTime.get(siteID).add(currentTick);
    }

    private void fail(int siteID) {
        sites.dm.get(siteID).fail();
        siteToFailTime.putIfAbsent(siteID, new ArrayList<>());
        siteToFailTime.get(siteID).add(currentTick);
        for (String tranName : transactions.keySet()) {
            if (transactions.get(tranName).accessedSites.contains(siteID)) {
                transactions.get(tranName).abort();
            }
        }
    }

    private void end(String transName) {
        if (transactions.get(transName).aborted) {
            abort(transName);
            System.out.println("Abort: " + transName);
        } else {
            deleteHoldLock(transName);
            deleteWaitFor(transName);
            for (int siteID : transactions.get(transName).accessedSites) {
                DataManager dm = sites.dm.get(siteID);
                dm.commit(transName, currentTick);
                dm.releaseLocks(transName);
            }
            System.out.println("Commit: " + transName);
        }
        transactions.remove(transName);
    }

    private void beginro(Transaction transaction) {
        for (int i = 1; i < sites.dm.size(); ++i) {
            if (!siteToFailTime.containsKey(i)) {
                transaction.readOnlyList.add(new int[]{i, 0});
            } else {
                int latest = -1;
                for (int time : siteToFailTime.get(i)) {
                    if (time < currentTick && time > latest) latest = time;
                }
                if (latest != -1) {
                    int recovery = -1;
                    for (int time : siteToRecoverTime.get(i)) {
                        if (time > latest) {
                            recovery = time;
                            break;
                        }
                    }
                    if (recovery != -1) transaction.readOnlyList.add(new int[]{i, recovery});
                }
            }
        }
    }

    private Map<String, Set<String>> createWaitForGraph() {
        Map<String, Set<String>> graph = new HashMap<>();
        for (String varName : waitForTrans.keySet()) {
            if (!waitForTrans.get(varName).isEmpty()) {
                String firstTran = waitForTrans.get(varName).get(0);
                graph.putIfAbsent(firstTran, new HashSet<>());
                //System.out.println(holdLockTrans.getOrDefault(varName, new ArrayList<>()));
                graph.get(firstTran).addAll(holdLockTrans.getOrDefault(varName, new ArrayList<>()));
                String prevTran = firstTran;
                //System.out.println(waitForTrans.getOrDefault(varName, new ArrayList<>()));
                for (int i = 1; i < waitForTrans.get(varName).size(); ++i) {
                    String curTran = waitForTrans.get(varName).get(i);
                    graph.putIfAbsent(curTran, new HashSet<>());
                    graph.get(curTran).add(prevTran);
                    prevTran = curTran;
                }
            }
        }
        return graph;
    }

    private void abortDeadlock(String transName) {
        Map<String, Set<String>> graph = createWaitForGraph();
        //System.out.println(graph);
        List<List<String>> deadlocks = getDeadlocks(graph, transName);

        Set<String> abortTrans = new HashSet<>();
        for (List<String> deadlock : deadlocks) {
            if (deadlock.size() <= 1) continue;
            System.out.println("Deadlock detected: " + deadlock);
            String toAbort = deadlock.get(0);
            for (String tran : deadlock) {
                if (transactions.get(tran).timestamp > transactions.get(toAbort).timestamp) {
                    toAbort = tran;
                }
            }
            abortTrans.add(toAbort);
        }

        for (String abortTran : abortTrans) {
            System.out.println("Abort due to deadlock: " + abortTran);
            transactions.get(abortTran).abort();
            abort(abortTran);
//            System.out.println(holdLockTrans);
//            System.out.println(waitForTrans);
        }
    }

    private List<List<String>> getDeadlocks(Map<String, Set<String>> graph, String transName) {
        List<List<String>> deadlocks = new ArrayList<>();
//        System.out.println(graph);
//        System.out.println(transName);
        dfs(graph, transName, transName, new ArrayList<>(), deadlocks);
        return deadlocks;
    }

    private void dfs(Map<String, Set<String>> graph, String transName, String cur, List<String> path, List<List<String>> deadlocks) {
        path.add(cur);
//        System.out.println(graph);
//        System.out.println(path);
        if (graph.containsKey(cur)) {
            for (String nxt : graph.get(cur)) {
                if (nxt.equals(transName)) {
                    deadlocks.add(new ArrayList<>(path));
                } else {
                    dfs(graph, transName, nxt, path, deadlocks);
                }
            }
        }
        path.remove(path.size() - 1);
    }

    private List<Integer> getAvailableSites(String varName) {
        List<Integer> res = new ArrayList<>();
        for (int i = 1; i < sites.dm.size(); ++i) {
            if (sites.dm.get(i).isUp && sites.dm.get(i).variables.containsKey(varName)) {
                res.add(i);
            }
        }

        return res;
    }

    private void putHoldLock(String varName, String transName) {
        holdLockTrans.putIfAbsent(varName, new ArrayList<>());
        if (!holdLockTrans.get(varName).contains(transName)) holdLockTrans.get(varName).add(transName);
    }

    private void putWaitFor(String varName, String transName) {
        waitForTrans.putIfAbsent(varName, new ArrayList<>());
        if (!waitForTrans.get(varName).contains(transName)) waitForTrans.get(varName).add(transName);
    }

    private void deleteHoldLock(String transName) {
        for (String varName : holdLockTrans.keySet()) {
            holdLockTrans.get(varName).remove(transName);
        }
    }

    private void deleteWaitFor(String transName) {
        for (String varName : waitForTrans.keySet()) {
            waitForTrans.get(varName).remove(transName);
        }
    }

    private void abort(String transName) {
        deleteHoldLock(transName);
        deleteWaitFor(transName);
        for (int siteID : transactions.get(transName).accessedSites) {
            sites.dm.get(siteID).reset(transName);
            sites.dm.get(siteID).releaseLocks(transName);
        }
        operationList.removeIf(operation -> operation.transName.equals(transName));
    }

    private void addOperation(Operation operation) {
        if (!operationList.contains(operation)) operationList.add(operation);
    }
}

class DataManager {
    int siteID;
    boolean isUp;
    Map<String, Lock> lockTable;
    Map<String, Variable> variables; // stored variables
    Map<String, List<Commit>> commits;

    public DataManager(int siteID) {
        this.siteID = siteID;
        isUp = true;
        lockTable = new HashMap<>();
        variables = new HashMap<>();
        commits = new HashMap<>();
    }

    public boolean canRead(String varName) {
        return variables.containsKey(varName) && variables.get(varName).canRead;
    }

    public void fail() {
        isUp = false;
        initLockTable();
        for (String varName : variables.keySet()) {
            variables.get(varName).canRead = false;
        }
    }

    public void recover() {
        isUp = true;
        for (String varName : variables.keySet()) {
            if (variables.get(varName).isUnique) variables.get(varName).canRead = true;
        }
    }

    public int read(String varName) {
        return variables.get(varName).valueToCommit;
    }

    public void write(String varName, int val) {
        variables.get(varName).valueToCommit = val;
        variables.get(varName).canRead = true;
    }

    public void dump() {
        PriorityQueue<Map.Entry<String, Variable>> pq = new PriorityQueue<>((a, b) -> {
            if (a.getKey().length() == b.getKey().length()) return a.getKey().compareTo(b.getKey());
            return Integer.compare(a.getKey().length(), b.getKey().length());
        });
        for (Map.Entry<String, Variable> entry : variables.entrySet()) pq.offer(entry);
        while (!pq.isEmpty()) {
            Map.Entry<String, Variable> entry = pq.poll();
            System.out.format(" %s:%d", entry.getKey(), entry.getValue().value);
        }
    }

    public Integer readOnly(String varName, int latestRecovery, int transStartTime) {
        Integer res = null;
        int latestTime = -1;
        for (Commit commit : commits.get(varName)) {
            if (commit.timestamp >= latestRecovery && commit.timestamp <= transStartTime && commit.timestamp > latestTime) {
                latestTime = commit.timestamp;
                res = commit.value;
            }
        }
        return res;
    }

    public Integer readOnlyUnique(String varName, int transStartTime) {
        return readOnly(varName, -1, transStartTime);
    }

    public void initLockTable() {
        for (String varName : variables.keySet()) {
            lockTable.put(varName, new Lock());
        }
    }

    public boolean getWriteLock(Operation operation, boolean hasWaitingCandidate) {
        String transName = operation.transName;
        String varName = operation.varName;
        boolean flag = false;
//        System.out.println(varName);
//        System.out.println(lockTable.get(varName).writeLock);
//        System.out.println(lockTable.get(varName).readLock);
        if (lockTable.get(varName).writeLock != null) {
            //System.out.println("line 536 " + flag);
            flag = lockTable.get(varName).writeLock.equals(transName);
        } else {
            if (lockTable.get(varName).readLock.isEmpty()) {
                flag = true;
            } else {
                if (lockTable.get(varName).readLock.size() == 1 && lockTable.get(varName).readLock.contains(transName)) {
                    flag = !hasWaitingCandidate;
                }
            }
        }
        if (flag) lockTable.get(varName).writeLock = transName;
//        System.out.println(lockTable.get(varName).writeLock);
//        System.out.println("line 547 " + flag);
        return flag;
    }

    public boolean getReadLock(Operation operation) {
        String transName = operation.transName;
        String varName = operation.varName;
        boolean flag = false;

        if (lockTable.get(varName).readLock.contains(transName)
                || (lockTable.get(varName).writeLock != null && lockTable.get(varName).writeLock.equals(transName))) {
            flag = true;
        } else if (canRead(varName)) {
            if (lockTable.get(varName).writeLock == null) {
                lockTable.get(varName).readLock.add(transName);
                flag = true;
            }
        }

        return flag;
    }

    public void commit(String transName, int timestamp) {
        for (String varName : lockTable.keySet()) {
            if (lockTable.get(varName).writeLock != null && lockTable.get(varName).writeLock.equals(transName)) {
                variables.get(varName).commit();
                commits.get(varName).add(new Commit(timestamp, variables.get(varName).value));
            }
        }
    }

    public void reset(String transName) {
        for (String varName : lockTable.keySet()) {
            if (lockTable.get(varName).writeLock != null && lockTable.get(varName).writeLock.equals(transName)) {
                variables.get(varName).reset();
            }
        }
    }

    public void releaseWriteLock(String transName, String varName) {
        if (lockTable.get(varName).writeLock != null && lockTable.get(varName).writeLock.equals(transName)) {
            lockTable.get(varName).releaseWriteLock();
        }
    }

    public void releaseLocks(String transName) {
        for (String varName : lockTable.keySet()) {
            lockTable.get(varName).readLock.remove(transName);
            if (lockTable.get(varName).writeLock != null && lockTable.get(varName).writeLock.equals(transName)) {
                lockTable.get(varName).releaseWriteLock();
            }
        }
    }
}

class Site {
    List<DataManager> dm;
    public Site(int siteCnt, int varCnt) {
        this.dm = new ArrayList<>();
        for (int i = 0; i <= siteCnt; ++i) {
            dm.add(new DataManager(i));
        }

        initialize(varCnt);
    }

    private void initialize(int varCnt) {
        for (int i = 1; i <= varCnt; ++i) {
            if (i % 2 == 1) {
                dm.get(i % 10 + 1).variables.put("x" + i, new Variable(true, true, i * 10));
            } else {
                for (DataManager dataManager : dm) {
                    dataManager.variables.put("x" + i, new Variable(false, true, i * 10));
                }
            }
        }

        for (DataManager dataManager : dm) {
            dataManager.initLockTable();
            for (String varName : dataManager.variables.keySet()) {
                dataManager.commits.putIfAbsent(varName, new ArrayList<>());
                dataManager.commits.get(varName).add(new Commit(0, dataManager.variables.get(varName).value));
            }
        }
    }
}

class Transaction {
    int timestamp;
    boolean readOnly, aborted;
    List<Integer> accessedSites; // [siteID]
    List<int[]> readOnlyList; // [siteID, latestRecoveryTime]

    public Transaction(int timestamp, boolean readOnly) {
        this.timestamp = timestamp;
        this.readOnly = readOnly;
        aborted = false;
        accessedSites = new ArrayList<>();
        readOnlyList = new ArrayList<>();
    }

    public void abort() {
        aborted = true;
    }
}

class Operation {
    int siteID;
    int value;
    boolean readUniqueVar;
    String operation; // read, write, begin, end
    String transName;
    String varName;
    String operateStr;
    Set<Integer> readOnlySites;
    List<int[]> readOnlySiteRecovery; // [siteID, latestRecoveryTime]

    public Operation(String input) {
        siteID = 0;
        readUniqueVar = false;
        transName = "";
        varName = null;
        readOnlySites = new HashSet<>();
        readOnlySiteRecovery = new ArrayList<>();

        input = input.replace('\n', ' ').trim().toLowerCase();
//        input = input.replace('\n', ' ').trim();
        //System.out.println(input);
        operateStr = input;
        String reg = "[^a-zA-Z0-9]+";
        String[] arr = input.split(reg);
        //System.out.println(Arrays.toString(arr));

        operation = arr[0];
        if (operation.equals("fail") || operation.equals("recover")) {
            siteID = Integer.parseInt(arr[1]);
        } else if (!operation.equals("dump")) {
            transName = arr[1];
            if (arr.length > 2 && !arr[2].equals(" ")) varName = arr[2];
            if (arr.length > 3 && !arr[3].equals(" ")) value = Integer.parseInt(arr[3]);
        }
    }
}

class Lock {
    Set<String> readLock; // <transName>
    String writeLock;

    public Lock() {
        readLock = new HashSet<>();
        writeLock = null;
    }

    public void releaseWriteLock() {
        writeLock = null;
    }
}

class Commit {
    int timestamp;
    int value;

    public Commit(int timestamp, int value) {
        this.timestamp = timestamp;
        this.value = value;
    }
}

class Variable {
    boolean isUnique, canRead;
    int value, valueToCommit; // write value not yet commit

    public Variable(boolean isUnique, boolean canRead, int value) {
        this.isUnique = isUnique;
        this.canRead = canRead;
        this.value = value;
        this.valueToCommit = value;
    }

    public void commit() {
        this.value = this.valueToCommit;
    }

    public void reset() {
        this.valueToCommit = this.value;
    }
}
