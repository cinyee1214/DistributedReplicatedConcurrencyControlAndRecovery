## Team members
Xinyi Zhao xz2833@nyu.edu 

Wanyi Zhang wz866@nyu.edu

## Project Structure
Entrance: ```Main.java```

Classes:
```angular2html
TransactionManager
DataManager
Commit
Lock
Operation
Site
Transaction
Variable
```

Executable: ```AdvancedDatabaseSystems.jar```

Reprozip: ```finalProject.rpz```

Zip: ```finalProject.rpz```

Run algorithm:
```java -jar AdvancedDatabaseSystems.jar <test-file-path> <output-file-path>```

For example:
```java -jar AdvancedDatabaseSystems.jar tests/testcase1.txt output/testcase1.txt```

